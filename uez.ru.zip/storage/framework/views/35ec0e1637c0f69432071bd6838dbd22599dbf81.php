<?php $__env->startSection('content'); ?>

<div class="ui top attached secondary segment">
	<?php echo e($address); ?>

</div>
<div class="ui attached segment" style="margin-bottom: 40px">
	<table class="ui very basic selectable table">
		<thead>
			<th>Счетчик</th>
			<th>Дата последних показаний</th>
			<th>Последние показание</th>
			<th>Новые показания</th>
		</thead>
		<tbody>
			<?php foreach($meters as $meter): ?>
			
			<?php if($meter->status_id == -2): ?>
				<tr class="warning">
					<td><?php echo e($meter->service->name); ?></td>
					<td colspan="3">Приостановлен</td>
				</tr>
			<?php elseif($meter->status_id == -1): ?>
				<tr class="negative">
					<td><?php echo e($meter->service->name); ?></td>
					<td colspan="3">Заблокирован</td>
				</tr>
			<?php else: ?>
				<tr>
					<td><?php echo e($meter->service->name); ?></td>
					<td><?php echo e($meter->last_date); ?></td>
					<td><?php echo e($meter->last_value); ?></td>
					<td>
						<input type="number" step="any">
					</td>
				</tr>
			<?php endif; ?>

			<?php endforeach; ?>
		</tbody>
	</table>
</div>


<script type="text/javascript">


</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>