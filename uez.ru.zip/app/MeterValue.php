<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class MeterValue extends Model
{
    //
}
