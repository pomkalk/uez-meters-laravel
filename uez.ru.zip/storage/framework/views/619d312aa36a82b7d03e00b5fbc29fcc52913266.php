
<nav class="navbar navbar-default navbar-fixed-bottom">
	<div class="container-fluid">
		<span class="navbar-text">
			<a href="http://uez-lk.ru">ООО «УЕЗ ЖКУ г. Ленинска-Кузнецкого» 2015 ©</a>
		</span>
		<div class="navbar-right">
			<span class="navbar-text">
				©Разработчик: Pomka inc. (email:<a href="mailto:pomkalk@gmail.com">pomkalk@gmail.com</a>)
			</span>
		</div>		
	</div>
</nav>