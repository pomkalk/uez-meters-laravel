<?php $__env->startSection('active-setup'); ?>
class="active"
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<div class="panel">
		<div class="panel-heading">
			<h2>Настройки</h2>
		</div>
		<div class="panel-body">
			<form action="<?php echo e(url('admin/setup')); ?>" method="post">
				<div class="checkbox">
					<label>
						<input type="checkbox" name="site-available" <?php echo e(AppConfig::get('site.available')?'checked':''); ?>> Разрешить доступ на сайт
					</label>
				</div>

				<div class="form-group">
					<label for="site-unmessage">Сообщение для пользователей, когда сайт недоступен</label>
					<textarea class="form-control" id="site-unmessage" name="site-unmessage"><?php echo e(AppConfig::get('site.unmessage')); ?></textarea>
				</div>

				<div class="row">
					<div class="col-md-3">
						<div class="form-group">
							<label for="start-date">Число начала приема показаний</label>
							<input type="number" min="1" max="31" class="form-control text-center" id="start-date" name="start-date" value="<?php echo e(AppConfig::get('work.s_date')); ?>">
						</div>
					</div>
					<div class="col-md-3">
						<div class="form-group">
							<label for="start-time">Время начала приема показаний</label>
							<input type="time" class="form-control text-center" id="start-time" name="start-time" value="<?php echo e(AppConfig::get('work.s_time')); ?>">
						</div>
					</div>
				</div>				
			</form>
		</div>	
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>