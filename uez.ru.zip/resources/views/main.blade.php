@extends('layouts.app')

@section('content')
	###asd


	some text
@stop