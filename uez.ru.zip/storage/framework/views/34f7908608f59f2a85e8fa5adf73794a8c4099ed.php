<?php $__env->startSection('content'); ?>



<div class="panel panel-default">
	<div class="panel-heading"><strong>Загрузить файл с показаниями</strong></div>
	<div class="panel-body">
		<?php if(count($errors)>0): ?>
			<div class="alert alert-danger">
				<ul>
					<?php foreach($errors->all() as $error): ?>
						<li><?php echo e($error); ?></li>
					<?php endforeach; ?>
				</ul>
			</div>
		<?php endif; ?>
		<form action="<?php echo e(url('admin/database/add')); ?>" method="post" enctype="multipart/form-data" autocomplete="off">
			<?php echo e(csrf_field()); ?>

			<div class="form-group">
				<label for="name">Название для файла</label>
				<input type="text" name="name" id="name" class="form-control">
			</div>
			<div class="form-group">
				<label for="xml">Укажите xml файл с данными</label>
				<input type="file" name="xml" id="xml" class="form-control">				
			</div>
			<button type="submit" class="btn btn-success">Отправить</button>
		</form>
	</div>
</div>





<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>