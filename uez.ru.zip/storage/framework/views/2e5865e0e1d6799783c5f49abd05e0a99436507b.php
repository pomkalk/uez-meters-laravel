<?php $__env->startSection('content'); ?>

<div class="panel panel-default">
	<div class="panel-heading"><strong>Сменить пароль</strong></div>
	<div class="panel-body">
		<?php if(session('success')): ?>
			<div class="alert alert-success">
				<?php echo e(session('success')); ?>

			</div>
		<?php endif; ?>
		<?php if(count($errors)>0): ?>
			<div class="alert alert-danger">
				<ul>
					<?php foreach($errors->all() as $error): ?>
						<li><?php echo e($error); ?></li>
					<?php endforeach; ?>
				</ul>
			</div>
		<?php endif; ?>

		<form class="form-horizontal" action="<?php echo e(url('admin/changepassword')); ?>" method="post">
			<?php echo e(csrf_field()); ?>

			<div class="form-group">
				<label class="col-md-2 control-label">Старый пароль</label>
				<div class="col-md-10">
					<input class="form-control" type="password" name="old_pass" id="new_pass">					
				</div>
			</div>
			<div class="form-group">
				<label class="col-md-2 control-label">Новый пароль</label>
				<div class="col-md-10">
					<input class="form-control" type="password" name="new_pass" id="new_pass">					
				</div>
			</div>
			<div class="form-group">
				<label class="col-md-2 control-label">Новый пароль еще раз</label>
				<div class="col-md-10">
					<input class="form-control" type="password" name="new_repeat" id="new_repeat">					
				</div>
			</div>
			<div class="text-right">
				<button type="submit" class="btn btn-success">Изменить</button>
			</div>
		</form>	
	</div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>