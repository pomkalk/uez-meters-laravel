<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
	<title>Ввод показаний</title>
	<link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('css/bootstrap-editable.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('css/styles.css')); ?>">
</head>
<body>
	<nav class="navbar navbar-default">
		<div class="container-fluid">
			<div class="navbar-header">
				<a class="navbar-brand" href="<?php echo e(url('/')); ?>">Ввод показаний индивидуальных приборов учета</a>
			</div>
		</div>
	</nav>
	<nav class="navbar">
		<div class="container-fluid">
			<div class="navbar-header">
				<span class="navbar-brand" href="<?php echo e(url('/')); ?>">ООО "УЕЗ ЖКУ г. Ленинска-Кузнецкого"</span>
			</div>
		</div>
	</nav>	
	
	<?php echo $__env->yieldContent('content'); ?>

	<?php echo $__env->make('layouts.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
	<script type="text/javascript" src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>

</body>
</html>