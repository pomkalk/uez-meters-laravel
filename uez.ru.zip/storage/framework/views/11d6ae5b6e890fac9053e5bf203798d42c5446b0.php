<?php $__env->startSection('content'); ?>

<div class="container-fluid">
	<div class="row">
		<div class="col-md-offset-3 col-md-6">
			<div class="panel">
				<div>
					<?php echo e(AppConfig::get('work.unmessage')); ?>	
				</div>
				<div class="text-right">
					<a href="http://uez-lk.ru">Вернуться на сайт УЕЗ ЖКУ</a>
				</div>
			</div>			
		</div>
	</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>