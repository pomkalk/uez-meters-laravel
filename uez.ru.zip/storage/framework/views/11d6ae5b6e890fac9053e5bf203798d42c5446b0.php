<?php $__env->startSection('content'); ?>
<div class="ui piled segment">
	<div class="ui horizontal divider">ВНИМАНИЕ</div>
	<?php echo e(AppConfig::get('work.unmessage')); ?>	
	<div class="ui divider"></div>
	<div class="ui basic right aligned segment">
		<a class="" href="http://uez-lk.ru">Вернуться</a>
	</div>


</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>