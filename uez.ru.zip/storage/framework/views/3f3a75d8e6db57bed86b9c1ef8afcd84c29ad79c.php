<?php $__env->startSection('content'); ?>

<div class="panel panel-default">
	<div class="panel-heading"><strong>Утилиты</strong></div>
	<div class="panel-body">
		<p><strong>Дополнительные программы для работы с данными.</strong></p>
		<p><a href="admin/utils/in_conv">In_conv</a> - Преобразует данные во входной формат.</p>
	</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>