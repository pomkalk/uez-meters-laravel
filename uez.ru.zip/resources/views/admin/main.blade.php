@extends('admin.layouts.app')

@section('content')
	asd
@stop