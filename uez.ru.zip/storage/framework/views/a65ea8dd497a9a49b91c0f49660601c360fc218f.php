<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
	<title>Административная панель</title>
	<link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('css/bootstrap-editable.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('css/admin/styles.css')); ?>">
</head>
<body>
	<nav class="navbar navbar-default">
		<div class="container-fluid">
			<div class="navbar-header">
				<button type="button" class="navbar-toggle collapsed">
					<span class="sr-only">Toggle navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
				<a class="navbar-brand" href="<?php echo e(url('/')); ?>"><span class="glyphicon glyphicon-home"></span></a>
				<a class="navbar-brand" href="<?php echo e(url('admin')); ?>">Административная панель</a>
			</div>
		</div>
	</nav>
	
	<div class="container-fluid">
		<div class="row">
			<div id="side-menu" class="col-md-3 col-sm-3">
				<div class="well well-sm">
					 Пользователь: <?php echo e(Auth::user()->name); ?> 
					 <br><a href="<?php echo e(url('admin/changepassword')); ?>">Сменить пароль</a>
				</div>
				<ul class="nav nav-pills nav-stacked">
					<li role="presentation" class="<?php echo e(Request::is('admin')?'active':''); ?>"><a href="<?php echo e(url('admin')); ?>">Dashboard</a></li>
					<li role="presentation" class="<?php echo e(Request::is('admin/database')?'active':''); ?>"><a href="<?php echo e(url('admin/database')); ?>">База данных</a></li>
					<li role="presentation" class="<?php echo e(Request::is('admin/feedback')?'active':''); ?>"><a href="<?php echo e(url('admin/feedback')); ?>">Отзывы</a></li>
					<li role="presentation" class="<?php echo e(Request::is('admin/settings')?'active':''); ?>"><a href="<?php echo e(url('admin/settings')); ?>">Настройки</a></li>
					<li role="presentation"><a href="<?php echo e(url('admin/logout')); ?>">Выйти</a></li>
				</ul>
			</div>

			<div class="col-md-9 col-sm-9">
				<?php echo $__env->yieldContent('content'); ?>			
			</div>
		</div>
	</div>

	<?php echo $__env->make('admin.layouts.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
	<script type="text/javascript" src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
	<!-- <script type="text/javascript" src="<?php echo e(asset('js/flat-ui.min.js')); ?>"></script> -->
	<script type="text/javascript" src="<?php echo e(asset('js/moment.js')); ?>"></script>	
	<script type="text/javascript" src="<?php echo e(asset('js/bootstrap-editable.min.js')); ?>"></script>
	<script type="text/javascript">
		$(function(){
			$(".navbar-toggle").click(function(){
				$("#side-menu").slideToggle('slow');
			});
		});
	</script>
	<?php echo $__env->yieldContent('script'); ?>
</body>
</html>