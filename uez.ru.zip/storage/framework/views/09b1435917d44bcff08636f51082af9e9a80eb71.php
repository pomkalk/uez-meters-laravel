<div class="ui bottom fixed stackable borderless menu">
	<div class="item">
		<a href="http://uez-lk.ru">ООО «УЕЗ ЖКУ г. Ленинска-Кузнецкого» 2015 ©</a>
	</div>
	<div class="right item">
		Разработчик: Pomka inc. (email:<a href="mailto:pomkalk@gmail.com">pomkalk@gmail.com</a>)
	</div>
</div>