<?php $__env->startSection('content'); ?>



<div class="panel panel-default">
	<div class="panel-heading"><strong>База данных счетчиков</strong></div>
	<div class="panel-body">
		<a href="<?php echo e(url('admin/database/add')); ?>" class="btn btn-success"><span class="glyphicon glyphicon-plus"></span>Добавить счетчики</button>
		</a>

		<?php if(count($errors)>0): ?>
			<div class="alert alert-danger">
				<ul>
					<?php foreach($errors->all() as $error): ?>
						<li><?php echo e($error); ?></li>
					<?php endforeach; ?>
				</ul>
			</div>
		<?php endif; ?>
		
		<?php if( count($files)>0 ): ?>
			<table class="table table-striped table-hover">
				<thead>
					<th>Название</th>
					<th>Дата загрузки</th>
					<th>Действие</th>
				</thead>
				<tbody>
					<?php foreach($files as $file): ?>
					<tr class="<?php echo e(($file->active)?'success':''); ?>">
						<td><?php echo e($file->name); ?></td>
						<td><?php echo e($file->created_at); ?></td>
						<td>
							<?php if(!$file->active): ?>
								<a href="<?php echo e(url('admin/database/activate')); ?>/<?php echo e($file->id); ?>">Активировать</a>|
							<?php endif; ?>
							<a href="<?php echo e(url('admin/database/delete')); ?>/<?php echo e($file->id); ?>">Удалить</a>
						</td>
					</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
		<?php else: ?>
		<p>Файлы не загружены</p>
		<?php endif; ?>
	</div>
</div>





<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="http://malsup.github.com/jquery.form.js"></script> 
<script type="text/javascript">
	$(function(){

	})
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>