<?php $__env->startSection('content'); ?>

<div class="ui top attached secondary segment">
	Укажите адрес
</div>
<div class="ui attached segment">
	<?php if(count($errors)>0): ?>
		<div class="ui error message">
			<ul>
				<?php foreach($errors->all() as $error): ?>
					<li><?php echo e($error); ?></li>
				<?php endforeach; ?>
			</ul>
		</div>
	<?php endif; ?>
	<form id="client-form" method="post" action="<?php echo e(url('/')); ?>" class="ui form" autocomplete="off">
	<?php echo e(csrf_field()); ?>

	<div id="streets" class="field">
		<label>Улица</label>
		<div class="ui fluid search selection dropdown">
			<input type="hidden" name="street">
			<i class="dropdown icon"></i>
			<div class="default text">Улица</div>
			<div class="menu">
				<?php foreach($streets as $street): ?>
				<div class="item" data-value='<?php echo e($street->id); ?>'><?php echo e($street->prefix.' '.$street->name); ?></div>
				<?php endforeach; ?>
			</div>
		</div>
	</div>
	<div id="buildings" class="disabled field">
		<label>Номер дома</label>
		<div class="ui fluid search selection dropdown">
			<input type="hidden" name="building">
			<i class="dropdown icon"></i>
			<div class="default text">Номер дома</div>
			<div class="menu">
				<?php foreach($streets as $street): ?>
				<div class="item" data-value='<?php echo e($street->id); ?>'><?php echo e($street->prefix.' '.$street->name); ?></div>
				<?php endforeach; ?>
			</div>
		</div>
	</div>
	<div id="apartments" class="disabled field">
		<label>Номер квартиры</label>
		<div class="ui fluid search selection dropdown">
			<input type="hidden" name="apartment">
			<i class="dropdown icon"></i>
			<div class="default text">Номер квартиры</div>
			<div class="menu">
				<?php foreach($streets as $street): ?>
				<div class="item" data-value='<?php echo e($street->id); ?>'><?php echo e($street->prefix.' '.$street->name); ?></div>
				<?php endforeach; ?>
			</div>
		</div>
	</div>		
	<div id="ls" class="disabled field">
		<label>Лицевой счет</label>
		<input type="number" name="ls" placeholder="Лицевой счет" >
	</div>
	<div id="space" class="disabled field">
		<label>Площадь</label>
		<input type="number" name="space" placeholder="Площадь" step="any">
	</div>	
	<div class="ui segment">
		<div align="center" class="g-recaptcha" data-sitekey="6LfjFxUTAAAAAIYJ4ljxOk1sXn0dU6nVggqh-3GJ" data-size="compact"></div>
	</div>
	<div class="ui basic center aligned segment">
		<div class="ui toggle checkbox">
			<input type="checkbox" name="remember">
			<label>Запомнить адрес</label>
		</div>		
	</div>
	<button type="submit" class="ui fluid green button">Найти адрес</button>
	</form>
</div>


<script type="text/javascript">
$request = null;
var stop_request = function(){
	if ($request != null)	
		$request.abort();
}
$(function(){

	var onApartmentChange = function(value, text, $item){
		console.log(value+": "+text);
		$('#ls input').val('');
		$('#space input').val('');
		$('#ls').removeClass('disabled');
		$('#space').removeClass('disabled');
		<?php if(old('ls')): ?>
			$('#ls input').val('<?php echo e(old("ls")); ?>');
		<?php endif; ?>
		<?php if(old('space')): ?>
			$('#space input').val('<?php echo e(old("space")); ?>');
		<?php endif; ?>				
	}

	var onBuildingChange = function(value, text, $item){
		$('#apartments .selection.dropdown').dropdown('restore defaults');
		if (value=='') 
			return;
		$('#apartments').addClass('disabled');
		$('#apartments .selection.dropdown').addClass('loading');
		$('#apartments .selection.dropdown').dropdown('restore defaults');

		$('#ls').addClass('disabled');
		$('#ls input').val('');
		$('#space').addClass('disabled');
		$('#space input').val('');

		$.get('<?php echo e(url("building")); ?>'+value,function(response){
			$('#apartments .dropdown .menu').html('');
			for (i in response)
			{
				var item = $('<div class="item" data-value="'+response[i].id+'">'+response[i].title+'</div>');
				$('#apartments .dropdown .menu').append(item);
			}
			$('#apartments .selection.dropdown').dropdown('refresh');

			$('#apartments .selection.dropdown').dropdown({
				onChange: onApartmentChange
			});
			$('#apartments .selection.dropdown').removeClass('loading');
			$('#apartments').removeClass('disabled');
			<?php if(old('apartment')): ?>
				$('#apartments .selection.dropdown').dropdown('set selected', '<?php echo e(old("apartment")); ?>');
			<?php endif; ?>
		},'json');		
	}

	var onStreetChange = function(value, text, $item){
		if (value=='') 
			return;
		$('#buildings').addClass('disabled');
		$('#buildings .selection.dropdown').addClass('loading');
		$('#buildings .selection.dropdown').dropdown('restore defaults');
		$('#apartments').addClass('disabled');

		$('#ls').addClass('disabled');
		$('#ls input').val('');
		$('#space').addClass('disabled');
		$('#space input').val('');

		$.get('<?php echo e(url("street")); ?>'+value,function(response){
			$('#buildings .dropdown .menu').html('');
			for (i in response)
			{
				var item = $('<div class="item" data-value="'+response[i].id+'">'+response[i].title+'</div>');
				$('#buildings .dropdown .menu').append(item);
			}
			$('#buildings .selection.dropdown').dropdown('refresh');

			$('#buildings .selection.dropdown').dropdown({
				onChange: onBuildingChange
			});
			$('#buildings .selection.dropdown').removeClass('loading');
			$('#buildings').removeClass('disabled');
			<?php if(old('building')): ?>
				$('#buildings .selection.dropdown').dropdown('set selected', '<?php echo e(old("building")); ?>');
			<?php endif; ?>
		},'json');
	}




	$('#streets .dropdown').dropdown({
		fullTextSearch:true, 
		onChange: onStreetChange
	});

	$('#submitButton').click(function(){
		var $form = $(this).closest('form');
		
	});

	$('button.green.button').click(function(){
		$(this).addClass('loading');
	});

	<?php if(count($errors)>0): ?>
		$('#streets .selection.dropdown').dropdown('set selected', '<?php echo e(old("street")); ?>');
	<?php endif; ?>

})

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>